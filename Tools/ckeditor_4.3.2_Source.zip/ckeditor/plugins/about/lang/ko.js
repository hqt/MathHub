﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'ko', {
	copy: '저작권 &copy; $1 . 판권 소유.',
	dlgTitle: 'CKEditor 에 대하여',
	help: '도움이 필요하시면 $1 를 확인하세요',
	moreInfo: '라이센스에 대한  정보를 보고싶다면 우리의 웹 사이트를 방문하세요:',
	title: 'CKEditor에 대하여',
	userGuide: 'CKEditor User\'s Guide'
} );
